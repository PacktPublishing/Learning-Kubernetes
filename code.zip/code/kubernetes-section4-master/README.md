# kubernetes-section4
Sample spring boot project (Simple rest web service) to containerize and deploy to kubernetes

The .zip file contains some handy instructions on how containerize and deploy this app to minikube and expose it as a service
